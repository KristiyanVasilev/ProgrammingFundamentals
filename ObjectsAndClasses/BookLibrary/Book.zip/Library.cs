﻿using System.Collections.Generic;

namespace BookLibrary
{
    public class Library
    {
        public string Name { get; set; }
        public List<Book> Books { get; set; }
    }
}
