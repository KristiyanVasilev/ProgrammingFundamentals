﻿namespace BookLibrary
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class BookLibrary
    {
        public static void Main()
        {
            var n = int.Parse(Console.ReadLine());
            var books = new List<Book>();
            var result = new Dictionary<string, double>();

            for (int i = 0; i < n; i++)
            {
                var line = Console.ReadLine().Split();
                var book = new Book
                {
                    Title = line[0],
                    Author = line[1],
                    Publisher = line[2],
                    ReleaseDate = line[3],
                    ISBN = line[4],
                    Price = double.Parse(line[5])
                };

                books.Add(book);
                if (!result.ContainsKey(book.Author))
                {
                    result[book.Author] = 0;
                }
                result[book.Author] += book.Price;
                result.OrderByDescending(x => x.Value).ThenBy(x => x.Key);
            }
            foreach (var authorsName in result)
            {
                Console.WriteLine($"{authorsName.Key:f2} -> {authorsName.Value:f2}");
            }
        }
    }
}
